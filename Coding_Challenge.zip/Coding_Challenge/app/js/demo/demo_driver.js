(function () {
    function DataFetcher(urlFactory, delay) {
        var self = this;

        self.repeat = false;
        self.delay = delay;
        self.timer = null;
        self.requestObj = null;

        function getNext() {
            self.requestObj = $.ajax({
                    url: urlFactory()
                }).done(function(response) {
                    $(self).trigger("stateFetchingSuccess", {
                        result: response
                    });
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    $(self).trigger("stateFetchingFailure", {
                        error: textStatus
                    });
                }).always(function() {
                    if (self.repeat && _.isNumber(self.delay)) {
                        self.timer = setTimeout(getNext, self.delay);
                    }
                });
        }

        self.start = function(shouldRepeat) {
            self.repeat = shouldRepeat;
            getNext();
        };

        self.stop = function() {
            self.repeat = false;
            clearTimeout(self.timer);
        };

        self.repeatOnce = function() {
            getNext();
        };

        self.setDelay = function(newDelay) {
            this.delay = newDelay;
        };
    }

    
    function addNewEntry($container, bardata) {
    var margin = { top:30, right:3 , bottom:30 , left:3 } 

var height = 400 - margin.top - margin.bottom,
    width = 40 - margin.left - margin.right,
    barWidth = 50,
    barOffset = 1;

var colors = d3.scale.linear() // linear scale for wide color range from light to dark  
    .domain([1, bardata.length * .33, bardata.length * .66, bardata.length]) // from 0, 25%, 75%, to end length of array
    .range(['#B58929', '#C61C6F', '#268BD2', '#85992C']) // 4 colors range  

var yScale = d3.scale.linear() //Quantitave scale, set the values automatically according to height
    .domain([0, d3.max(bardata)]) // set the max hight of the bar 
    .range([0, height])

var xScale = d3.scale.ordinal() //Ordinal scale
    .domain(d3.range(0, bardata.length)) // length of bardata array
    .rangeBands([0, width]) //special method to set the range in ordinal scale 

var tooltip = d3.select('body').append('div')
    .style('position', 'absolute')
    .style('padding', '0 10px')
    .style('background', 'white')
    .style('opacity', 0)

var myChart = d3.select('#chart').append('svg') // svg 
    .attr('width', width)
    .attr('height', height)
    .append('g')
    .selectAll('rect').data(bardata) // bars according to bar data array 
    .enter().append('rect') // rectangle method directly in d3
    .style('fill', function(d, i) {
        return colors(i); // function to set colors from orange to pink from left to right 
    }) // style of bars
    .attr('width', xScale.rangeBand()) // use "rangeBand()" not s to set the width
    .attr('height', 0)
    .attr('x', function(d, i) {
        return xScale(i);
    })
    .attr('y', height)
    .attr('height', 0)

.on('mouseover', function(d) {
        tooltip.transition()
            .style('opacity', .9)

        tooltip.html(d)
            .style('left', (d3.event.pageX - 35) + 'px')
            .style('top', (d3.event.pageY - 30) + 'px')

        tempColor = this.style.fill;
        d3.select(this)
            .style('opacity', .5)
            .style('fill', 'yellow')
    })
    .on('mouseout', function(d) {
        d3.select(this)
            .style('opacity', 1)
            .style('fill', tempColor)
    })
myChart.transition() // transition of the whole chart
    .attr('height', function(d) {
        return yScale(d);
    })
    .attr('y', function(d) {
        return height - yScale(d);
    })
    .delay(function(d, i) {
        return i * 20;
    })
    .duration(1000)
    .ease('elastic') // method for bouncy style transition

var vGuideScale = d3.scale.linear()
    .domain([0, d3.max(bardata)])
    .range([height, 0])

var vAxis = d3.svg.axis() //vertical axis
    .scale(vGuideScale)
    .orient('left')
    .ticks(10)

var vGuide = d3.select('svg').append('g') //guide of the vertical axis 
    vAxis(vGuide)
    vGuide.attr('transform', 'translate(35, 0)')
    vGuide.selectAll('path')
        .style({fill: 'none', stroke: '#000'})
    vGuide.selectAll('line')
        .style({stroke:'#000'})

var hAxis = d3.svg.axis() // horizontal axis 
    .scale(xScale)
    .orient('bottom')
    .tickValues(xScale.domain().filter(function(d, i){
        return !(i % (bardata.length/5));
    }))

var hGuide = d3.select('svg').append('g')
    hAxis(hGuide)
    hGuide.attr('transform', 'translate(0, ' + (height-30) + ')')
    hGuide.selectAll('path')
        .style({fill: 'none', stroke: '#000'})
    hGuide.selectAll('line')
        .style({stroke:'#000'})
}


    var $trafficStatusList = $("#mockTrafficStat"),
        df2 = new DataFetcher(function() {
            return "/traffic_status";
        });

    $(df2).on({
        "stateFetchingSuccess": function(event, data) {
            data.result.data.forEach(function(dataEntry) {
                addNewEntry($trafficStatusList, JSON.stringify(dataEntry.traffic), JSON.stringify(dataEntry.packets));
            });
        },
        "stateFetchingFailure": function(event, data) {
            addNewEntry($trafficStatusList, JSON.stringify(data.error));
            addNewEntry($trafficStatusList, "Hit a snag. Retry after 1 sec...");
            setTimeout(function() {
                $trafficStatusList.html("");
                df2.repeatOnce();
            }, 1000);
        }
    });

    df2.start();
})();